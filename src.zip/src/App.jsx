import React from "react";
import Home from "./home/Home";
import { Route, Routes } from "react-router-dom";
import Courses from "./courses/Courses";
import Contacts from "./components/Contact/Contacts";
import Aboutus from "./components/About Us/Aboutus";
import Login from "./components/Login";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/contact" element={<Contacts />} />
        <Route path="/about" element={<Aboutus />} />
        <Route path="/login" element={<Login />}/>
      </Routes>

    </>
  );
}

export default App;
